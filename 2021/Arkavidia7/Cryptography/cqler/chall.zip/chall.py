#!/usr/bin/python3
from Crypto.Util.number import *
from secret import flag
import base64

class Unbuffered(object):
   def __init__(self, stream):
       self.stream = stream
   def write(self, data):
       self.stream.write(data)
       self.stream.flush()
   def writelines(self, datas):
       self.stream.writelines(datas)
       self.stream.flush()
   def __getattr__(self, attr):
       return getattr(self.stream, attr)

sys.stdout = Unbuffered(sys.stdout)

def menu():
    print("""
Choose a menu:
1. Hash something
2. Encrypt something
3. Reset
4. Redeem the Secret Gift Box
5. Exit
    """)

def reset():
    cqler = CQLER()
    print("Key: {}".format(cqler.e))
    print("Encrypted flag: {}".format(cqler.encrypt_flag()))
    return cqler

class CQLER:
    def __init__(self):
        self.c = getPrime(512)
        self.q = getPrime(512)
        self.l = getPrime(519)
        self.e = getPrime(520)
        self.r = getPrime(520)
        
    def encrypt_flag(self):
        assert(bytes_to_long(flag.encode("utf-8")) <= self.e)
        r = (self.c << 1) ^ (self.q << 3)
        for x in flag:
            r = r ^ ord(x)
            for i in range(8):
                r = (r >> 1) ^ (self.e if r & 1 else 0)
        r = pow(r ^ self.l, 0x10001, self.r)
        return base64.b64encode(long_to_bytes(r)).decode("utf-8")

    def decrypt(self, c, n):
        r = bytes_to_long(c) << n*8
        r ^= self.r ^ (self.q << 5) ^ (self.l << (n*4))
        for i in range(r.bit_length(), 520, -1):
            r ^= (self.e << (i-520)) ^ (1 << (i-521)) if (r >> i-1) else 0
        return long_to_bytes(r)[::-1]

    def encrypt(self, m):
        n = len(m)
        r = self.r ^ (self.q << 5) ^ (self.l << (n*4))
        for x in m:
            r = r ^ x
            for i in range(8):
                r = (r >> 1) ^ (self.e if r & 1 else 0)
        return (base64.b64encode(long_to_bytes(r)).decode("utf-8"), n)

    def hash(self, m):
        r = self.c ^ (self.q << 3) ^ (self.l << (len(m)*8))
        for x in m:
            r = r ^ x ^ (x << 2)
            for i in range(8):
                r = (r >> 1) ^ (self.e if r & 1 else 0)
        self.c = r
        return base64.b64encode(long_to_bytes(r)).decode("utf-8")

    def redeem(self, c, n):
        m = self.decrypt(c, n)
        return m == b"s3cr3t_r3d33m_c0de_st0nks"

print("""
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
         CQLER MACHINE
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

~ It's not just a cryptosystem

""")
cqler = reset()
i = 3

try:
    while i:
        print("\nCounter -", i)
        menu()
        x = int(input("Input your choice: "))
        if x == 1:
            m = base64.b64decode(input("Input your message: "))
            if len(m) >= 5 and bytes_to_long(m) >= 2**24:
                print("Hashed message: {}".format(cqler.hash(m)))
            else:
                print("Message is too short")
        elif x == 2:
            m = base64.b64decode(input("Input your message: "))
            if len(m) >= 5 and bytes_to_long(m) >= 2**24 and bytes_to_long(m) != bytes_to_long(b"s3cr3t_r3d33m_c0de_st0nks"):
                print("Encrypted message: {}".format(cqler.encrypt(m)))
            else:
                print("Message is not valid")
        elif x == 3:
            cqler = reset()
        elif x == 4:
            c = base64.b64decode(input("Input your code: "))
            n = int(input("Input your code length: "))
            if cqler.redeem(c, n):
                print("Congratz! You got bonus try!")
                i += 2
        else:
            print("Goodbye...")
            exit()
        i -= 1
except Exception:
    print("Error has occured.")